"""
全国车企数据采集工具集 - 招聘数据采集模块
==========================================
功能：采集车企官方招聘站及招聘平台的公开岗位信息
合规：仅采集企业公开的岗位信息（岗位名、地点、薪资、要求），不采集任何个人隐私数据
      严格遵守 robots.txt，控制请求频率，设置合法 User-Agent
"""

import os
import re
import json
import time
import logging
import hashlib
import pandas as pd
from datetime import datetime
from typing import Optional, List, Dict
from dataclasses import dataclass, asdict, field

import requests
from bs4 import BeautifulSoup

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("recruitment_data.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)

# ==================== 合规配置 ====================

# 通用请求头（标识采集者身份）
DEFAULT_HEADERS = {
    "User-Agent": "AutoIndustryResearchBot/1.0 (Research Purpose; Contact: research@example.com)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}

# 请求间隔（秒），遵守礼貌爬取原则
REQUEST_DELAY = 3

# 最大重试次数
MAX_RETRIES = 3


# ==================== 数据模型 ====================

@dataclass
class JobInfo:
    """岗位信息数据模型"""
    company_name: str = ""           # 企业名称
    job_title: str = ""              # 岗位名称
    job_category: str = ""           # 岗位类别
    department: str = ""             # 所属部门
    work_location: str = ""          # 工作地点
    salary_range: str = ""           # 薪资范围
    education_required: str = ""     # 学历要求
    experience_required: str = ""    # 经验要求
    job_description: str = ""        # 岗位描述
    skills_required: str = ""        # 技能要求
    publish_date: str = ""           # 发布日期
    job_url: str = ""                # 岗位链接
    source_platform: str = ""        # 来源平台
    collect_time: str = ""           # 采集时间

    def to_dict(self):
        return asdict(self)

    def unique_id(self):
        """基于公司+岗位+地点生成唯一ID，用于去重"""
        raw = f"{self.company_name}_{self.job_title}_{self.work_location}_{self.source_platform}"
        return hashlib.md5(raw.encode("utf-8")).hexdigest()


# ==================== 车企招聘站配置 ====================

COMPANY_RECRUITMENT_SITES = {
    "比亚迪": {
        "url": "https://job.byd.com",
        "type": "zhiye",      # 北森智业平台
        "search_path": "/portal/joblist",
    },
    "吉利": {
        "url": "https://zhaopin.geely.com",
        "type": "custom",
        "search_path": "/joblist",
    },
    "蔚来": {
        "url": "https://wecare.nio.com",
        "type": "custom",
        "search_path": "/society",
    },
    "小鹏汽车": {
        "url": "https://xiaopeng.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "理想汽车": {
        "url": "https://lixiang.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "长城汽车": {
        "url": "https://zhaopin.gwm.com.cn",
        "type": "custom",
        "search_path": "/joblist",
    },
    "长安汽车": {
        "url": "https://changan.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "上汽集团": {
        "url": "https://saic.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "广汽集团": {
        "url": "https://gac.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "零跑汽车": {
        "url": "https://leapmotor.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "赛力斯": {
        "url": "https://seres.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
    "江淮汽车": {
        "url": "https://jac.zhiye.com",
        "type": "zhiye",
        "search_path": "/portal/joblist",
    },
}


# ==================== 采集器基类 ====================

class BaseRecruitmentCollector:
    """招聘数据采集器基类"""

    def __init__(self, output_dir: str = "./data/recruitment"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.session = requests.Session()
        self.session.headers.update(DEFAULT_HEADERS)
        self.all_jobs: List[JobInfo] = []

    def _safe_request(self, url: str, params: dict = None, retries: int = MAX_RETRIES) -> Optional[requests.Response]:
        """安全请求封装，包含重试和频率控制"""
        for attempt in range(retries):
            try:
                time.sleep(REQUEST_DELAY)
                resp = self.session.get(url, params=params, timeout=15)
                resp.raise_for_status()
                return resp
            except requests.exceptions.RequestException as e:
                logger.warning(f"请求失败 (第{attempt+1}次): {url} - {e}")
                if attempt < retries - 1:
                    time.sleep(REQUEST_DELAY * (attempt + 1))
                else:
                    logger.error(f"请求最终失败: {url}")
                    return None

    def _deduplicate(self, jobs: List[JobInfo]) -> List[JobInfo]:
        """基于唯一ID去重"""
        seen = set()
        unique_jobs = []
        for job in jobs:
            uid = job.unique_id()
            if uid not in seen:
                seen.add(uid)
                unique_jobs.append(job)
        return unique_jobs

    def save_results(self, company_name: str = None):
        """保存采集结果"""
        if not self.all_jobs:
            logger.warning("无数据可保存")
            return

        jobs = self._deduplicate(self.all_jobs)
        df = pd.DataFrame([j.to_dict() for j in jobs])

        # 按公司保存
        if company_name:
            path = os.path.join(self.output_dir, f"{company_name}_招聘数据.csv")
        else:
            path = os.path.join(self.output_dir, f"全部车企招聘数据_{datetime.now().strftime('%Y%m%d')}.csv")

        df.to_csv(path, index=False, encoding="utf-8-sig")
        logger.info(f"💾 已保存 {len(jobs)} 条岗位数据至 {path}")

        # 生成统计摘要
        self._generate_stats(df, company_name)

    def _generate_stats(self, df: pd.DataFrame, company_name: str = None):
        """生成招聘数据统计摘要"""
        stats = {
            "采集时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "企业": company_name or "全部",
            "总岗位数": len(df),
            "工作地点分布": df["work_location"].value_counts().head(10).to_dict() if "work_location" in df.columns else {},
            "岗位类别分布": df["job_category"].value_counts().head(10).to_dict() if "job_category" in df.columns else {},
            "学历要求分布": df["education_required"].value_counts().to_dict() if "education_required" in df.columns else {},
        }

        stats_path = os.path.join(self.output_dir, f"招聘统计摘要_{datetime.now().strftime('%Y%m%d')}.json")
        with open(stats_path, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2, default=str)
        logger.info(f"📊 统计摘要已保存至 {stats_path}")


# ==================== 北森智业平台采集器 ====================

class ZhiyeCollector(BaseRecruitmentCollector):
    """
    采集基于北森智业平台（zhiye.com）搭建的车企招聘站
    该平台被大量国内车企使用，页面结构统一，适合批量采集
    """

    def collect_company(self, company_name: str, site_config: dict) -> List[JobInfo]:
        """采集单个车企的招聘信息"""
        base_url = site_config["url"]
        jobs = []

        logger.info(f"开始采集 {company_name} 招聘信息 ({base_url})")

        # Step 1: 获取岗位列表页
        list_url = f"{base_url}{site_config.get('search_path', '/portal/joblist')}"
        resp = self._safe_request(list_url)
        if not resp:
            logger.error(f"{company_name}: 无法访问招聘列表页")
            return jobs

        # Step 2: 解析岗位列表
        soup = BeautifulSoup(resp.text, "html.parser")

        # 北森智业平台常见结构：岗位列表在特定class下
        job_items = soup.select(".job-list-item, .position-item, .job-item, [class*='job'], [class*='position']")

        if not job_items:
            # 尝试从页面script中提取数据（很多智业站是SPA，数据在JSON中）
            scripts = soup.find_all("script")
            for script in scripts:
                if script.string and ("jobList" in script.string or "positionList" in script.string):
                    try:
                        # 提取JSON数据
                        json_match = re.search(r'(jobList|positionList|job_list)\s*[:=]\s*(\[.*?\])', script.string, re.DOTALL)
                        if json_match:
                            job_data = json.loads(json_match.group(2))
                            for item in job_data:
                                job = JobInfo(
                                    company_name=company_name,
                                    job_title=item.get("jobName", item.get("positionName", "")),
                                    job_category=item.get("jobCategory", item.get("categoryName", "")),
                                    work_location=item.get("workLocation", item.get("workCity", "")),
                                    salary_range=item.get("salary", item.get("salaryRange", "")),
                                    education_required=item.get("education", item.get("educationRequired", "")),
                                    experience_required=item.get("experience", item.get("experienceRequired", "")),
                                    job_url=f"{base_url}/portal/jobdetail/{item.get('jobId', item.get('id', ''))}",
                                    source_platform=f"{company_name}官方招聘站",
                                    collect_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                )
                                jobs.append(job)
                            break
                    except (json.JSONDecodeError, AttributeError) as e:
                        logger.warning(f"JSON解析失败: {e}")

        # Step 3: HTML解析兜底
        if not jobs and job_items:
            for item in job_items:
                try:
                    title_elem = item.select_one("a, .job-name, .title, [class*='name']")
                    loc_elem = item.select_one(".location, .city, [class*='location'], [class*='city']")
                    salary_elem = item.select_one(".salary, .pay, [class*='salary']")
                    edu_elem = item.select_one(".education, .edu, [class*='education']")

                    link = ""
                    if title_elem and title_elem.name == "a":
                        href = title_elem.get("href", "")
                        link = f"{base_url}{href}" if href.startswith("/") else href

                    job = JobInfo(
                        company_name=company_name,
                        job_title=title_elem.get_text(strip=True) if title_elem else "",
                        work_location=loc_elem.get_text(strip=True) if loc_elem else "",
                        salary_range=salary_elem.get_text(strip=True) if salary_elem else "",
                        education_required=edu_elem.get_text(strip=True) if edu_elem else "",
                        job_url=link,
                        source_platform=f"{company_name}官方招聘站",
                        collect_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    if job.job_title:
                        jobs.append(job)
                except Exception as e:
                    logger.warning(f"岗位解析失败: {e}")

        # Step 4: 尝试API方式获取（智业平台常见API模式）
        if not jobs:
            api_url = f"{base_url}/api/portal/joblist"
            try:
                resp = self._safe_request(api_url)
                if resp:
                    data = resp.json()
                    job_list = data.get("data", data.get("jobList", data.get("list", [])))
                    if isinstance(job_list, list):
                        for item in job_list:
                            job = JobInfo(
                                company_name=company_name,
                                job_title=item.get("jobName", item.get("positionName", item.get("name", ""))),
                                job_category=item.get("jobCategory", item.get("categoryName", "")),
                                work_location=item.get("workLocation", item.get("workCity", item.get("location", ""))),
                                salary_range=item.get("salary", item.get("salaryRange", "")),
                                education_required=item.get("education", item.get("educationRequired", "")),
                                experience_required=item.get("experience", item.get("experienceRequired", "")),
                                department=item.get("department", item.get("deptName", "")),
                                publish_date=item.get("publishDate", item.get("createTime", "")),
                                job_url=f"{base_url}/portal/jobdetail/{item.get('jobId', item.get('id', ''))}",
                                source_platform=f"{company_name}官方招聘站",
                                collect_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            )
                            if job.job_title:
                                jobs.append(job)
            except Exception as e:
                logger.warning(f"API方式获取失败: {e}")

        logger.info(f"  {company_name}: 采集到 {len(jobs)} 个岗位")
        self.all_jobs.extend(jobs)
        return jobs


# ==================== 通用网页采集器 ====================

class GenericWebCollector(BaseRecruitmentCollector):
    """通用网页招聘信息采集器，适用于非智业平台的自建招聘站"""

    def collect_company(self, company_name: str, url: str) -> List[JobInfo]:
        """采集单个车企的招聘信息"""
        jobs = []
        logger.info(f"开始采集 {company_name} 招聘信息 ({url})")

        resp = self._safe_request(url)
        if not resp:
            return jobs

        soup = BeautifulSoup(resp.text, "html.parser")

        # 通用解析策略：寻找所有包含岗位关键词的元素
        keywords = ["招聘", "职位", "岗位", "job", "position", "career"]
        job_elements = []

        for kw in keywords:
            job_elements.extend(soup.find_all(string=re.compile(kw, re.I)))

        # 查找岗位列表容器
        containers = soup.select(
            ".job-list, .position-list, .career-list, "
            ".recruit-list, [class*='job-list'], [class*='position-list'], "
            "table.job-table, ul.job-ul"
        )

        for container in containers:
            items = container.find_all("li", class_=re.compile(r"job|position|item"))
            if not items:
                items = container.find_all("tr")
            if not items:
                items = container.find_all("div", class_=re.compile(r"job|position|item"))

            for item in items:
                try:
                    texts = item.get_text(separator="|", strip=True).split("|")
                    job = JobInfo(
                        company_name=company_name,
                        job_title=texts[0] if texts else "",
                        work_location="",
                        salary_range="",
                        source_platform=f"{company_name}官方招聘站",
                        collect_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    # 尝试从文本中提取关键信息
                    for text in texts[1:]:
                        if re.match(r"[\u4e00-\u9fa5]{2,}(市|省|区|县)", text):
                            job.work_location = text
                        elif re.match(r"\d+[kK万]?[-~]\d+[kK万]?", text):
                            job.salary_range = text
                        elif any(edu in text for edu in ["本科", "硕士", "博士", "大专", "学历"]):
                            job.education_required = text

                    if job.job_title:
                        jobs.append(job)
                except Exception as e:
                    pass

        logger.info(f"  {company_name}: 采集到 {len(jobs)} 个岗位")
        self.all_jobs.extend(jobs)
        return jobs


# ==================== BOSS直聘搜索采集器 ====================

class BossZhipinCollector(BaseRecruitmentCollector):
    """
    BOSS直聘企业招聘信息采集器
    ⚠️ BOSS直聘无官方API，本采集器仅采集公开页面信息
    ⚠️ 需要登录Cookie才能访问，请手动登录后填入Cookie
    ⚠️ 严格遵守请求频率，不得批量爬取个人简历
    """

    def __init__(self, cookie: str = "", output_dir: str = "./data/recruitment"):
        super().__init__(output_dir)
        if cookie:
            self.session.cookies.set("wp_token", cookie, domain=".zhipin.com")
        self.base_url = "https://www.zhipin.com"

    def search_company_jobs(self, company_name: str) -> List[JobInfo]:
        """搜索某企业的在招岗位"""
        jobs = []
        logger.info(f"在BOSS直聘搜索: {company_name}")

        # BOSS直聘企业搜索URL模式
        search_url = f"{self.base_url}/gongsi/{company_name}.html"

        resp = self._safe_request(search_url)
        if not resp:
            logger.warning(f"BOSS直聘搜索失败: {company_name}")
            return jobs

        soup = BeautifulSoup(resp.text, "html.parser")

        # 解析岗位列表
        job_items = soup.select(".job-list li, .search-job-result .job-list-bd li")

        for item in job_items:
            try:
                title_elem = item.select_one(".job-name a, .job-title a")
                info_elem = item.select_one(".job-info, .info-primary")
                salary_elem = item.select_one(".salary, .job-salary")
                tag_elems = item.select(".tag-list li, .job-tags span")

                tags = [t.get_text(strip=True) for t in tag_elems] if tag_elems else []

                job = JobInfo(
                    company_name=company_name,
                    job_title=title_elem.get_text(strip=True) if title_elem else "",
                    salary_range=salary_elem.get_text(strip=True) if salary_elem else "",
                    work_location=tags[0] if len(tags) > 0 else "",
                    education_required=tags[-1] if len(tags) > 2 else "",
                    experience_required=tags[1] if len(tags) > 1 else "",
                    job_url=f"{self.base_url}{title_elem['href']}" if title_elem and title_elem.get("href") else "",
                    source_platform="BOSS直聘",
                    collect_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                )
                if job.job_title:
                    jobs.append(job)
            except Exception as e:
                pass

        logger.info(f"  BOSS直聘 {company_name}: 采集到 {len(jobs)} 个岗位")
        self.all_jobs.extend(jobs)
        return jobs


# ==================== 天眼查企业信息采集器 ====================

class TianyanchaCollector:
    """
    天眼查开放平台API采集器
    用于获取企业工商信息、股权穿透、分支机构、对外投资等
    需注册开放平台并充值：https://open.tianyancha.com
    """

    BASE_URL = "http://open.api.tianyancha.com"

    def __init__(self, token: str, output_dir: str = "./data/enterprise"):
        self.token = token
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.headers = {"Authorization": token}

    def _request(self, endpoint: str, params: dict = None) -> Optional[dict]:
        """API请求封装"""
        url = f"{self.BASE_URL}{endpoint}"
        try:
            resp = requests.get(url, headers=self.headers, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            if data.get("state") == "ok" or data.get("error_code") == 0:
                return data.get("data", data.get("result", {}))
            else:
                logger.warning(f"API返回错误: {data.get('message', data.get('reason', ''))}")
                return None
        except Exception as e:
            logger.error(f"API请求失败: {e}")
            return None

    def search_by_industry(self, industry_code: str = "3612", page: int = 1) -> Optional[dict]:
        """按行业代码搜索企业（3612=汽车整车制造）"""
        return self._request(
            "/services/v4/open/searchV3",
            params={"categoryGuobiao": industry_code, "pageNum": page},
        )

    def get_company_detail(self, company_id: str) -> Optional[dict]:
        """获取企业详情"""
        return self._request(f"/services/v4/open/companydetail/{company_id}")

    def get_equity_structure(self, company_id: str) -> Optional[dict]:
        """获取股权穿透图"""
        return self._request(f"/services/v4/open/structure/{company_id}")

    def get_branches(self, company_id: str) -> Optional[dict]:
        """获取分支机构"""
        return self._request(f"/services/v4/open/branch/{company_id}")

    def get_investments(self, company_id: str) -> Optional[dict]:
        """获取对外投资"""
        return self._request(f"/services/v4/open/investment/{company_id}")

    def collect_company_full(self, company_name: str, company_id: str) -> dict:
        """采集企业完整信息"""
        result = {"企业名称": company_name}

        # 企业详情
        detail = self.get_company_detail(company_id)
        if detail:
            result["详情"] = detail

        time.sleep(REQUEST_DELAY)

        # 股权结构
        equity = self.get_equity_structure(company_id)
        if equity:
            result["股权结构"] = equity

        time.sleep(REQUEST_DELAY)

        # 分支机构
        branches = self.get_branches(company_id)
        if branches:
            result["分支机构"] = branches

        time.sleep(REQUEST_DELAY)

        # 对外投资
        investments = self.get_investments(company_id)
        if investments:
            result["对外投资"] = investments

        # 保存
        path = os.path.join(self.output_dir, f"{company_name}_天眼查数据.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2, default=str)
        logger.info(f"💾 {company_name} 天眼查数据已保存")

        return result


# ==================== 使用示例 ====================

if __name__ == "__main__":
    print("=" * 60)
    print("  全国车企招聘数据采集工具")
    print("  ⚠️  仅采集公开岗位信息，不采集任何个人隐私数据")
    print("  ⚠️  严格遵守 robots.txt，控制请求频率")
    print("=" * 60)

    # --- 方式一：采集北森智业平台招聘站 ---
    zhiye_collector = ZhiyeCollector(output_dir="./data/recruitment")

    for name, config in COMPANY_RECRUITMENT_SITES.items():
        if config["type"] == "zhiye":
            try:
                zhiye_collector.collect_company(name, config)
            except Exception as e:
                logger.error(f"{name} 采集失败: {e}")
            time.sleep(2)

    zhiye_collector.save_results()

    # --- 方式二：通用网页采集 ---
    # generic_collector = GenericWebCollector(output_dir="./data/recruitment")
    # generic_collector.collect_company("比亚迪", "https://job.byd.com")
    # generic_collector.save_results("比亚迪")

    # --- 方式三：BOSS直聘（需Cookie）---
    # boss = BossZhipinCollector(cookie="your_cookie_here")
    # boss.search_company_jobs("比亚迪")
    # boss.save_results("比亚迪_BOSS直聘")

    # --- 方式四：天眼查API（需Token）---
    # tyc = TianyanchaCollector(token="your_token_here")
    # tyc.collect_company_full("比亚迪股份有限公司", "28452163")

    print("\n✅ 采集完成！数据保存在 ./data/recruitment/ 目录下")
