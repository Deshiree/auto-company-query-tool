"""
全国车企数据采集工具集 - 财务数据采集模块
==========================================
功能：基于 AKShare / Tushare / BaoStock 批量采集上市车企财务数据
合规：仅采集公开披露的上市公司财务数据，不涉及任何个人隐私信息
"""

import os
import json
import time
import logging
import pandas as pd
from datetime import datetime
from abc import ABC, abstractmethod
from typing import Optional

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("financial_data.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)


# ==================== 上市车企股票代码配置 ====================

STOCK_LIST = {
    # A股上市车企
    "上汽集团": "600104",    # 上交所
    "比亚迪": "002594",      # 深交所
    "长城汽车": "601633",    # 上交所
    "长安汽车": "000625",    # 深交所
    "广汽集团": "601238",    # 上交所
    "江淮汽车": "600418",    # 上交所
    "赛力斯": "601127",      # 上交所
    "北汽蓝谷": "600733",    # 上交所
    "海马汽车": "000572",    # 深交所
    "力帆科技": "601777",    # 上交所
    "一汽解放": "000800",    # 深交所
    "中国重汽": "000951",    # 深交所
    "宇通客车": "600066",    # 上交所
    "金龙汽车": "600686",    # 上交所
    "中通客车": "000957",    # 深交所
    "福田汽车": "600166",    # 上交所
    "汉马科技": "600375",    # 上交所
    "曙光股份": "600303",    # 上交所
    "金杯汽车": "600609",    # 上交所
    "众泰汽车": "000980",    # 深交所
    "东风汽车": "600006",    # 上交所（东风集团A股子公司）
    "华域汽车": "600741",    # 上交所（零部件）
    # 港股上市车企（AKShare部分支持）
    "吉利汽车": "00175",     # 港交所
    "东风集团": "00489",     # 港交所
    "北汽股份": "01958",     # 港交所
    "零跑汽车": "09863",     # 港交所
    "蔚来-SW": "09866",     # 港交所
    "小鹏汽车-W": "09868",  # 港交所
    "理想汽车-W": "02015",  # 港交所
}


class BaseFinancialCollector(ABC):
    """财务数据采集器基类"""

    def __init__(self, output_dir: str = "./data/financial"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    @abstractmethod
    def get_profit_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取利润表"""
        pass

    @abstractmethod
    def get_balance_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取资产负债表"""
        pass

    @abstractmethod
    def get_cash_flow(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取现金流量表"""
        pass

    @abstractmethod
    def get_financial_indicator(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取财务指标"""
        pass

    def collect_all(self, stock_code: str, company_name: str, year: int):
        """采集指定公司指定年份的全部财务数据"""
        logger.info(f"开始采集 {company_name}({stock_code}) {year}年 财务数据")

        results = {}
        data_types = {
            "利润表": self.get_profit_sheet,
            "资产负债表": self.get_balance_sheet,
            "现金流量表": self.get_cash_flow,
            "财务指标": self.get_financial_indicator,
        }

        for dtype, func in data_types.items():
            try:
                df = func(stock_code, year)
                if df is not None and not df.empty:
                    results[dtype] = df
                    logger.info(f"  ✅ {dtype}: 获取到 {len(df)} 条记录")
                else:
                    logger.warning(f"  ⚠️ {dtype}: 无数据")
            except Exception as e:
                logger.error(f"  ❌ {dtype}: 采集失败 - {e}")
            time.sleep(1)  # 请求间隔，避免频率过高

        # 保存结果
        if results:
            output_path = os.path.join(
                self.output_dir, f"{company_name}_{stock_code}_{year}.xlsx"
            )
            with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
                for dtype, df in results.items():
                    df.to_excel(writer, sheet_name=dtype[:31], index=False)
            logger.info(f"  💾 已保存至 {output_path}")

        return results

    def batch_collect(self, year: int, stock_dict: Optional[dict] = None):
        """批量采集多家车企财务数据"""
        if stock_dict is None:
            stock_dict = STOCK_LIST

        all_results = {}
        total = len(stock_dict)

        for i, (name, code) in enumerate(stock_dict.items(), 1):
            logger.info(f"[{i}/{total}] 正在采集: {name}({code})")
            try:
                results = self.collect_all(code, name, year)
                all_results[name] = results
            except Exception as e:
                logger.error(f"[{i}/{total}] {name} 采集失败: {e}")
            time.sleep(2)  # 请求间隔

        # 汇总报告
        self._generate_summary(all_results, year)
        return all_results

    def _generate_summary(self, all_results: dict, year: int):
        """生成采集汇总报告"""
        summary = []
        for name, results in all_results.items():
            row = {"企业名称": name}
            for dtype in ["利润表", "资产负债表", "现金流量表", "财务指标"]:
                row[dtype] = "✅" if dtype in results and results[dtype] is not None else "❌"
            summary.append(row)

        df_summary = pd.DataFrame(summary)
        summary_path = os.path.join(self.output_dir, f"采集汇总_{year}.csv")
        df_summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
        logger.info(f"汇总报告已保存至 {summary_path}")


# ==================== AKShare 采集器 ====================

class AKShareCollector(BaseFinancialCollector):
    """基于 AKShare 的财务数据采集器（免费，推荐首选）"""

    def __init__(self, output_dir: str = "./data/financial"):
        super().__init__(output_dir)
        try:
            import akshare as ak
            self.ak = ak
            logger.info("AKShare 初始化成功")
        except ImportError:
            raise ImportError("请先安装 AKShare: pip install akshare")

    def _format_a_stock_code(self, code: str) -> str:
        """格式化A股代码为AKShare格式（如 600104 -> sh600104, 000625 -> sz000625）"""
        if code.startswith("6") or code.startswith("9"):
            return f"sh{code}"
        elif code.startswith("0") or code.startswith("3"):
            return f"sz{code}"
        return code

    def get_profit_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取利润表"""
        try:
            symbol = self._format_a_stock_code(stock_code)
            df = self.ak.stock_profit_sheet_by_report_em(symbol=symbol)
            if df is not None and not df.empty:
                # 筛选指定年度
                df["报告期"] = pd.to_datetime(df["报告期"])
                df = df[df["报告期"].dt.year == year]
            return df
        except Exception as e:
            logger.error(f"利润表采集异常: {e}")
            return None

    def get_balance_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取资产负债表"""
        try:
            symbol = self._format_a_stock_code(stock_code)
            df = self.ak.stock_balance_sheet_by_report_em(symbol=symbol)
            if df is not None and not df.empty:
                df["报告期"] = pd.to_datetime(df["报告期"])
                df = df[df["报告期"].dt.year == year]
            return df
        except Exception as e:
            logger.error(f"资产负债表采集异常: {e}")
            return None

    def get_cash_flow(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取现金流量表"""
        try:
            symbol = self._format_a_stock_code(stock_code)
            df = self.ak.stock_cash_flow_statement_by_report_em(symbol=symbol)
            if df is not None and not df.empty:
                df["报告期"] = pd.to_datetime(df["报告期"])
                df = df[df["报告期"].dt.year == year]
            return df
        except Exception as e:
            logger.error(f"现金流量表采集异常: {e}")
            return None

    def get_financial_indicator(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        """获取财务分析指标"""
        try:
            symbol = self._format_a_stock_code(stock_code)
            df = self.ak.stock_financial_analysis_indicator(symbol=symbol)
            if df is not None and not df.empty:
                df["日期"] = pd.to_datetime(df["日期"])
                df = df[df["日期"].dt.year == year]
            return df
        except Exception as e:
            logger.error(f"财务指标采集异常: {e}")
            return None


# ==================== Tushare 采集器 ====================

class TushareCollector(BaseFinancialCollector):
    """基于 Tushare Pro 的财务数据采集器（需注册获取Token）"""

    def __init__(self, token: str, output_dir: str = "./data/financial"):
        super().__init__(output_dir)
        try:
            import tushare as ts
            ts.set_token(token)
            self.pro = ts.pro_api()
            logger.info("Tushare Pro 初始化成功")
        except ImportError:
            raise ImportError("请先安装 Tushare: pip install tushare")

    def _get_period_list(self, year: int):
        """生成报告期列表"""
        return [
            f"{year}1231",  # 年报
            f"{year}0630",  # 半年报
            f"{year}0331",  # 一季报
            f"{year}0930",  # 三季报
        ]

    def get_profit_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            periods = self._get_period_list(year)
            dfs = []
            for period in periods:
                df = self.pro.income(ts_code=f"{stock_code}.SZ", period=period)
                if df is not None and not df.empty:
                    dfs.append(df)
                time.sleep(0.5)
            # 也尝试上交所后缀
            if not dfs:
                for period in periods:
                    df = self.pro.income(ts_code=f"{stock_code}.SH", period=period)
                    if df is not None and not df.empty:
                        dfs.append(df)
                    time.sleep(0.5)
            return pd.concat(dfs) if dfs else None
        except Exception as e:
            logger.error(f"利润表采集异常: {e}")
            return None

    def get_balance_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            periods = self._get_period_list(year)
            dfs = []
            for suffix in [".SZ", ".SH"]:
                for period in periods:
                    df = self.pro.balancesheet(ts_code=f"{stock_code}{suffix}", period=period)
                    if df is not None and not df.empty:
                        dfs.append(df)
                    time.sleep(0.5)
                if dfs:
                    break
            return pd.concat(dfs) if dfs else None
        except Exception as e:
            logger.error(f"资产负债表采集异常: {e}")
            return None

    def get_cash_flow(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            periods = self._get_period_list(year)
            dfs = []
            for suffix in [".SZ", ".SH"]:
                for period in periods:
                    df = self.pro.cashflow(ts_code=f"{stock_code}{suffix}", period=period)
                    if df is not None and not df.empty:
                        dfs.append(df)
                    time.sleep(0.5)
                if dfs:
                    break
            return pd.concat(dfs) if dfs else None
        except Exception as e:
            logger.error(f"现金流量表采集异常: {e}")
            return None

    def get_financial_indicator(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            periods = self._get_period_list(year)
            dfs = []
            for suffix in [".SZ", ".SH"]:
                for period in periods:
                    df = self.pro.fina_indicator(ts_code=f"{stock_code}{suffix}", period=period)
                    if df is not None and not df.empty:
                        dfs.append(df)
                    time.sleep(0.5)
                if dfs:
                    break
            return pd.concat(dfs) if dfs else None
        except Exception as e:
            logger.error(f"财务指标采集异常: {e}")
            return None


# ==================== BaoStock 采集器 ====================

class BaoStockCollector(BaseFinancialCollector):
    """基于 BaoStock 的财务数据采集器（免费，无需注册）"""

    def __init__(self, output_dir: str = "./data/financial"):
        super().__init__(output_dir)
        try:
            import baostock as bs
            self.bs = bs
            lg = bs.login()
            if lg.error_code != "0":
                raise ConnectionError(f"BaoStock 登录失败: {lg.error_msg}")
            logger.info("BaoStock 初始化成功")
        except ImportError:
            raise ImportError("请先安装 BaoStock: pip install baostock")

    def __del__(self):
        try:
            self.bs.logout()
        except:
            pass

    def _format_code(self, code: str) -> str:
        """格式化股票代码（如 600104 -> sh.600104）"""
        if code.startswith("6") or code.startswith("9"):
            return f"sh.{code}"
        elif code.startswith("0") or code.startswith("3"):
            return f"sz.{code}"
        return code

    def get_profit_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            symbol = self._format_code(stock_code)
            rs = self.bs.query_profit_data(code=symbol, year=year, quarter=4)
            data = []
            while (rs.error_code == "0") and rs.next():
                data.append(rs.get_row_data())
            if data:
                df = pd.DataFrame(data, columns=rs.fields)
                return df
            return None
        except Exception as e:
            logger.error(f"利润表采集异常: {e}")
            return None

    def get_balance_sheet(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            symbol = self._format_code(stock_code)
            rs = self.bs.query_balance_data(code=symbol, year=year, quarter=4)
            data = []
            while (rs.error_code == "0") and rs.next():
                data.append(rs.get_row_data())
            if data:
                df = pd.DataFrame(data, columns=rs.fields)
                return df
            return None
        except Exception as e:
            logger.error(f"资产负债表采集异常: {e}")
            return None

    def get_cash_flow(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            symbol = self._format_code(stock_code)
            rs = self.bs.query_cash_flow_data(code=symbol, year=year, quarter=4)
            data = []
            while (rs.error_code == "0") and rs.next():
                data.append(rs.get_row_data())
            if data:
                df = pd.DataFrame(data, columns=rs.fields)
                return df
            return None
        except Exception as e:
            logger.error(f"现金流量表采集异常: {e}")
            return None

    def get_financial_indicator(self, stock_code: str, year: int) -> Optional[pd.DataFrame]:
        try:
            symbol = self._format_code(stock_code)
            # BaoStock 的成长性/盈利能力等指标
            rs = self.bs.query_growth_data(code=symbol, year=year, quarter=4)
            data = []
            while (rs.error_code == "0") and rs.next():
                data.append(rs.get_row_data())
            if data:
                df = pd.DataFrame(data, columns=rs.fields)
                return df
            return None
        except Exception as e:
            logger.error(f"财务指标采集异常: {e}")
            return None


# ==================== 使用示例 ====================

if __name__ == "__main__":
    print("=" * 60)
    print("  全国车企财务数据采集工具")
    print("  数据源: AKShare (免费) / Tushare (需Token) / BaoStock (免费)")
    print("=" * 60)

    year = 2025  # 采集年份
    collector = AKShareCollector(output_dir="./data/financial")

    # 单企采集示例
    # collector.collect_all("600104", "上汽集团", year)

    # 批量采集
    collector.batch_collect(year)

    print("\n✅ 采集完成！数据保存在 ./data/financial/ 目录下")
